 #include<stdio.h>
 #include<stdlib.h>
 int arr[10][10],visited[10],vertex,size;
 void dfs(int);
 int main()
 {

        int i,j,source,count=0;
        printf("\n enter no of nodes=");
        scanf("%d",&size);
        printf("\n enter the adjacency matrix:");
        for(i=1;i<=size;i++)
        {
                    visited[i]=0;
                    for(j=1;j<=size;j++)
                    {
                        scanf("%d",&arr[i][j]);
                    }
      }
      printf("\n the adjacency matrix is:");
      for(i=1;i<=size;i++)
      {
                  for(j=1;j<=size;j++)
                  {
                      printf("%d", arr[i][j]);
                  }
                  printf("\n");
      }
      printf("\n enter starting node=");
      scanf("%d",&source);
      dfs(source);
      for(i=1;i<=size;i++)
              if(visited[i])
                  count++;
      if(count==size)
                printf("\n DFS connection");
      else
                printf("\n cannot generate dfs connection");
      }
      void dfs(int vertex)
      {
              int i;
              visited[vertex]=1;
              for(i=1;i<=size;i++)
              {
                      if(arr[vertex][i]==1 && visited[i]==0)
                      {
                              printf("DFS is %d->%d \n",vertex,i);
                              dfs(i);
                      }
                }
      }
