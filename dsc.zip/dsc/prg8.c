#include<stdio.h>
#include<stdlib.h>

void bubble(int c[],int n)
{
	int i,j,temp;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(c[j]>c[j+1])
			{
				temp=c[j];
				c[j]=c[j+1];
				c[j+1]=temp;
			}
		}
	}
	printf("\nSorted Array:");
	for(i=0;i<n;i++)
		printf("%d",c[i]);
}

void insertion(int a[],int n)
{
	int i,j,key;
	for(i=1;i<n;i++)
	{
		key=a[i];
		j=i-1;
		while(j>=0 && a[j]>key)
		{
			a[j+1]=a[j];
			j=j-1;
		}
		a[j+1]=key;
	}
	printf("Sorted array");
	for(i=0;i<n;i++)
		printf("\n%d",a[i]);
}

void selection(int a[],int n)
{
	int i,j,min,temp;
	for(i=0;i<n;i++)
	{
		min=i;
		for(j=i+1;j<n;j++)
		{
			if(a[j]<a[min])
				min=j;
		}
		temp=a[i];
		a[i]=a[min];
		a[min]=temp;
	}
	printf("Sorted Array:");
	for(i=0;i<n;i++)
		printf("\n%d",a[i]);
}

void main()
{
	int i,j,a[10],n,ch,temp;
	while(1)
	{
		printf("\nEnter size:");
		scanf("%d",&n);
		printf("\nEnter elements:");
		for(i=0;i<n;i++)
			scanf("%d",&a[i]);
		printf("Array elements are:");
		for(i=0;i<n;i++)
			printf("%d",a[i]);
		printf("1.Bubble\n2.Insertion\n3.Selection\nEnter your choice");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				bubble(a,n);
				break;
			case 2:
				insertion(a,n);
				break;
			case 3:
				selection(a,n);
				break;
			case 4:
				exit(0);
				break;
			default:
				printf("Invalid choice");
		}
	}
}
