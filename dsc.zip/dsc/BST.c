#include <stdio.h>
#include <stdlib.h>

struct node
{
	struct node *left,*right;
	int data;
}*root;

struct node *get_node(int a)
{
	  struct node *temp;
    temp = (struct node *)malloc(sizeof(struct node));
    temp ->data = a;
    temp->left = NULL;
    temp->right = NULL;
    return temp;
}



struct node*  insert(struct node *root, int data)
{
    if (root == NULL){
        root = get_node(data);
    }

    else if(data < root->data){
        root->left = insert(root->left,data);
    }
    else{
        root->right = insert(root->right,data);
    }
}


void inorder(struct node *temp)
{
	if(temp!=NULL)
	{
		inorder(temp->left);
		printf("%d---> ", temp->data);
		inorder(temp->right);
	}
}


void preorder(struct node *temp)
{
	if(temp!=NULL)
	{
		
		printf("%d---> ", temp->data);
		preorder(temp->left);
		preorder(temp->right);
	}
}

void postorder(struct node *temp)
{
	if(temp!=NULL)
	{
		postorder(temp->left);
		postorder(temp->right);
		printf("%d---> ", temp->data);
	}
}
void main()
{
	int a, val, choice;
	struct node *root=NULL;
	printf("Enter the Value of Root \n");
	scanf("%d", &a);
	root=insert(root, a);
	printf("The root Element is \n");
	printf("%d\n", root->data);
	 while(1)
    {
        printf("\n1.Create");
        printf("\n2. Traverse in Inorder");
        printf("\n3. Traverse in Preorder");
        printf("\n4. Traverse in Postorder");
        printf("\n5-Traverse in level\n");
        printf("\n6. Exit\n");
        printf("\nEnter your choice :");
        scanf("%d", &choice);

        switch (choice)
        {
			case 1:
				printf("\nEnter elements \n");
				scanf("%d",&val);
				insert(root,val);                      
				break;
          
        case 2:
			printf("InOder \n");
			inorder(root);
			break;
			
		 case 3:
			printf("Proorder \n");
			preorder(root);
			break;
			
		case 4:
			printf("Proorder \n");
			postorder(root);
			break;
            
            
         }

       
           
        }
	
	
}
