#include<stdio.h>
#define SIZE 100
void linear(int a[], int num, int n) {
int flag=0,i;
for(i=0;i<n;i++) {
if(a[i]==num) {
flag=1;
break;
} }
if(flag==1)
printf("Number %d found at position %d\n",num,i+1);
else
printf("Number not found");
}
void binary(int a[],int num, int n) {
int l=0,h=n-1,mid;
while(l<=h) {
mid=(l+h)/2;
if(num>a[mid])
l=mid+1;
else if(num==a[mid]) {
printf("number %d found at position %d\n", num, mid+1);
break;
}
else
l=mid-1;
}
if(l>h)
printf("Number not found");
}
void main() {
int n,num,ch,i,a[SIZE];
printf("Enter number of elements:\n");
scanf("%d",&n);
printf("Enter array elements:\n");
for(i=0;i<n;i++) {
scanf("%d",&a[i]);
}
printf("Enter the number to be searched");
scanf("%d",&num);
printf("Enter your choice:\n 1.Linear 2.Binary\n");
scanf("%d",&ch);
switch(ch){
case 1: 
linear(a,num,n);
break;
case 2:
binary(a,num,n);
break;
deafult:
printf("invalid choice");
break;
} }
