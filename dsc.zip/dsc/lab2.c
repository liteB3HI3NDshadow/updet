#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int top=-1,n;
void push(char a[5][10], char e[]) {
	if(top==n-1)
		printf("Stack is full\n");
	else {	
	
	//	printf("%d",top);
		strcpy(a[++top],e);
		printf("Element %s is pushed\n",e);
	}
}
void pop(char a[5][10]){
	if(top==-1)
		printf("Stack is underflow\n");
	else {
		printf("Element %s is popped\n",a[top--]);
	}
}

void peep(char a[5][10]){
	if(top==-1)
		printf("Stack is underflow\n");
	else
		printf("The topmost element is %s\n",a[top]);
}

void display(char a[5][10]) {
	if(top==-1) {
		printf("Stack is empty\n");
	}
	else
	{
		printf("The elements of stack are:\n");
		for(int i=top;i>=0;i--)
		printf("%s",a[i]);
	}
}

void main(){
	char a[5][10], e[10];
	printf("enter size of array\n");
	scanf("%d",&n);
	while(1) {
		int ch;
		printf("1.Insert\n 2.Delete\n 3.Peep\n 4.Display 5.Exit\nEnter your choice\n");
		scanf("%d",&ch);
		switch(ch) {
			case 1:
				printf("Enter element to be pushed\n");
				scanf("%s",e);
				push(a,e);
				break;
			case 2:
				pop(a);
			case 3:
				peep(a);
			case 4:
				display(a);
			case 5:
				exit(0);
			default:
				printf("invalid choice\n");
		}
	}
}
