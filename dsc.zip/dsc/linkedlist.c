#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node *next;
}*head=NULL, *new=NULL;
int len;

void begin(int a)
{
	new=(struct node*)malloc(sizeof(struct node));
	new->data=a;
	new->next=NULL;
	if(head==NULL)
		head=new;
	else
	{
		new->next=head;
		head=new;
	}
}

void end(int a)
{
	struct node *p=NULL;
	new=(struct node*)malloc(sizeof(struct node));
	new->data=a;
	new->next=NULL;
	p=head;
	while(p->next!=NULL)
		p=p->next;
	p->next=new;
}

int length()
{
	struct node *temp;
	int count=0;
	temp=head;
	while(temp!=NULL)
	{
		count++;
		temp=temp->next;
	}
	return count;
}

void middle(int a)
{
	struct node *p, *temp;
	int loc,i=0;
	len=length();
	if(len==0)
		printf("The list is empty");
	else
	{
		printf("Enter location to be added:");
		scanf("%d",&loc);
		if(loc>len)
			printf("Invalid location");
		else
		{
			p=head;
			while(i<loc)
			{
				p=p->next;
				i++;
			}
			temp=(struct node*)malloc(sizeof(struct node));
			temp->data=a;
			temp->next=p->next;
			p->next=temp;
		}
	}
}

void display()
{
	struct node *temp;
	if(new==NULL)
		printf("List is empty");
	else
	{
		temp=head;
		while(temp!=NULL)
		{
			printf("%d-->",temp->data);
			temp=temp->next;
		}
		printf("\n");
		len=length();
		printf("Total elements= %d",len);
	}
}

void main()
{
	int a;
	while(1)
	{
		int ch;
		printf("\n1.Insert at the begin\n2.Insert at the middle\n3.Insert at the end\n4.Display\n5.Exit\nEnter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("Enter element to be inserted:");
				scanf("%d",&a);
				begin(a);
				break;
			case 2:
				printf("Enter element to be inserted:");
				scanf("%d",&a);
				middle(a);
				break;
			case 3:
				printf("Enter element to be inserted:");
				scanf("%d",&a);
				end(a);
			case 4:
				display(a);
				break;
			case 5:
				exit(0);
				break;
			default:
				printf("Invalid choice");
		}
	}
}
